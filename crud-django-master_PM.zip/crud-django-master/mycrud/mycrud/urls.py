
from django.contrib import admin
from django.urls import path
from crush.views import *
from myapp.views import *


urlpatterns = [
    # crush
    path('admin/', admin.site.urls),
    path('sapa/', sapa, name='sapa'),
    # path('beranda/', home, name='home'),

    # myapp
    path('', index, name='index'),
    path('home/', beranda, name='beranda'),
    path('aboutus/', aboutus, name='aboutus'),

    path('divisi/', getDivisi, name='divisi'),
    path('pegawai/', getPegawai, name='pegawai'),
    path('pegawai/form', formPegawai, name='formPegawai'),
    path('divisi/form', formDivisi, name='formDivisi'),
    path('pegawai/create', createPegawai, name='createPegawai'),
    path('pegawai/update_pegawai<int:idedit>',
         formUpdatePegawai, name='updatePegawai'),


]
