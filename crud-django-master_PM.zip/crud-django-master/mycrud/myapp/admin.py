from django.contrib import admin
from .models import Divisi, Pegawai
# Register your models here.

admin.site.register(Divisi)
admin.site.register(Pegawai)
