from django.shortcuts import render, redirect
from .models import *
# Create your views here.


def index(request):
    return render(request, 'index.html')


def beranda(request):
    return render(request, 'beranda.html')


def aboutus(request):
    return render(request, 'aboutus.html')


def getDivisi(request):
    divisi_list = Divisi.objects.all()
    template = 'divisi.html'
    context = {
        'divisi_list': divisi_list
    }
    return render(request, template, context)


def getPegawai(request):
    pegawai_list = Pegawai.objects.all()
    template = 'pegawai.html'
    context = {
        'pegawai_list': pegawai_list
    }
    return render(request, template, context)


def formPegawai(request):
    template = 'form_pegawai.html'
    ar_pegawai = Pegawai.objects.all()
    ar_divisi = Divisi.objects.all()
    context = {
        'ar_pegawai': ar_pegawai,
        'ar_divisi': ar_divisi
    }
    return render(request, template, context)


def formDivisi(request):
    return render(request, 'form_divisi.html')


def createPegawai(request):
    if request.method == 'POST':
        nip = request.POST['nip']
        nama = request.POST['nama']
        alamat = request.POST['alamat']
        email = request.POST['email']
        divisi = request.POST['divisi']
        gender = request.POST['gender']
        divisi = Divisi.objects.get(id=divisi)
        Pegawai.objects.create(nama=nama, alamat=alamat,
                               divisi=divisi, nip=nip, gender=gender, email=email)

        return redirect('/pegawai/')


def formUpdatePegawai(request, idedit):
    template = 'update_pegawai.html'
    edit_pegawai = Pegawai.objects.filter(id=idedit)
    ar_divisi = Divisi.objects.all()
    context = {
        'edit_pegawai': edit_pegawai,
        'ar_divisi': ar_divisi,
    }

    if request.method == 'POST':
        print("Update Pegawai")
        return formUpdatePegawai(request, idedit=idedit)
    else:
        return render(request, template, context)


def updatePegawai(request, idedit="", action=""):
    if request.method == 'POST':
        nip = request.POST['nip']
        nama = request.POST['nama']
        gender = request.POST['gender']
        alamat = request.POST['alamat']
        email = request.POST['email']
        divisi = request.POST['divisi']

        Pegawai.objects.filter(id=idedit)
