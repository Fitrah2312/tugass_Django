from django.apps import AppConfig


class CrushConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'crush'
